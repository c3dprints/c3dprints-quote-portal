# C3D Prints Approve Job V1

Replace:
- backend/main.py
- frontend/admin.html

What it adds:
- final agreed price
- deposit paid yes/no
- due date
- print / production notes
- Save Job Details button
- Approve Job button
- backend route PATCH /admin/requests/{request_id}/job-details

Deploy:
1. Replace backend/main.py and commit/push.
2. Wait for Render redeploy.
3. Replace dashboard admin.html.
4. Test on a fake request first.

The backend auto-adds these Supabase/Postgres columns on startup:
- final_price
- deposit_paid
- due_date
- print_notes
