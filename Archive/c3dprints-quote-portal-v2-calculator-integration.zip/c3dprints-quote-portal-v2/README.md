# C3D Prints Quote Portal v2

Adds calculator integration.

Copy the backend files into your repo, commit, push, and redeploy Render.

Then open `frontend/internal-quote-calculator.html` to test the calculator API.
