# C3D Prints Status Management V1

This package gives you patches for status management.

Backend:
- add `VALID_STATUSES`
- add `StatusUpdateRequest`
- add `PATCH /admin/requests/{request_id}/status`

Frontend:
- add status dropdown/card
- add `updateStatus()`
- update request badge colors

Because your current files have changed a lot, this package uses patch snippets instead of overwriting your whole app.
