# C3D Prints Supabase Migration V1

This moves quote requests from Render's temporary SQLite file to Supabase Postgres.

## Files to replace

Replace in your backend repo:

```text
backend/main.py
backend/requirements.txt
```

Add for reference:

```text
backend/supabase_schema.sql
```

## Supabase setup

1. Create a Supabase project.
2. Go to SQL Editor.
3. Run the SQL from `backend/supabase_schema.sql`.

## Get connection string

In Supabase project dashboard, click **Connect**.

Use the **Session pooler** connection string if available. Supabase documents that the Shared Pooler is IPv4-only and useful when direct IPv6 connections are not an option.

It will look roughly like:

```text
postgresql://postgres.PROJECTREF:PASSWORD@aws-REGION.pooler.supabase.com:5432/postgres
```

## Render environment variable

In Render → Environment, add:

```text
DATABASE_URL=your_supabase_connection_string
```

Keep your existing variables:

```text
ADMIN_USERNAME
ADMIN_PASSWORD
JWT_SECRET
RESEND_API_KEY
FROM_EMAIL
QUOTE_NOTIFY_EMAIL
OPENAI_API_KEY
DEFAULT_KWH
DEFAULT_MARKUP
```

## Deploy

```bash
git add .
git commit -m "Move quote requests to Supabase"
git push
```

Render will redeploy.

## Test

Open:

```text
https://c3dprints-quote-portal.onrender.com/health
```

Expected:

```json
{
  "ok": true,
  "storage": "supabase_postgres",
  "database_configured": true,
  "quote_count": 0
}
```

Then submit a quote request and confirm it remains after Render sleeps/restarts.
