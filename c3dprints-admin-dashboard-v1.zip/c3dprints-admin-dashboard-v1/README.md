# C3D Prints Admin Dashboard V1

Upload `admin.html` to the root of your GitHub Pages repo.

Visit:
https://c3dprints.github.io/c3dprints-quote-portal/admin.html

Change the password inside admin.html:
const INTERNAL_PASSWORD = "ChangeThisPassword";

Features:
- Password gate
- Pulls quote requests from Render
- Shows selected request + AI summary
- Includes quote calculator
- Generates copyable customer reply
