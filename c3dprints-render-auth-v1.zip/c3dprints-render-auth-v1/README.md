# C3D Prints Render Auth V1

This update removes the visible HTML password and protects admin data at the Render backend.

## Files to add/replace

Backend:
- Add `backend/auth.py`
- Replace `backend/main.py`

Frontend:
- Replace your dashboard page with `frontend/admin_auth.html`
  - Rename it to `admin.html` when uploading to your dashboard repo.

## Required Render environment variables

Add these in Render → Environment:

```text
ADMIN_USERNAME=yourusername
ADMIN_PASSWORD=yourStrongPassword
JWT_SECRET=long-random-secret-value
```

Keep your existing values:
- RESEND_API_KEY
- FROM_EMAIL
- QUOTE_NOTIFY_EMAIL
- OPENAI_API_KEY
- DEFAULT_KWH
- DEFAULT_MARKUP

## After updating

Commit and push backend changes.
Render redeploys.
Then upload/replace the dashboard HTML.

## Test

1. Visit:
   https://dashboard.c3dprints.com

2. Log in with your Render env username/password.

3. If login succeeds but requests do not load, check:
   - Render logs
   - browser console
   - ALLOWED_ORIGINS includes dashboard domain if you are not using wildcard
