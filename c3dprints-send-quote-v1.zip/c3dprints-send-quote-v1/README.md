# C3D Prints Send Quote V1

Replace:
- backend/main.py
- frontend/admin.html

No requirements change is needed unless your repo is missing current Supabase/Postgres requirements.

What it adds:
- POST /admin/requests/{request_id}/send-quote
- Send Quote Email button
- Editable quote text
- Status auto-updates to Quoted after successful send

Test:
1. Deploy backend.
2. Open dashboard.
3. Select request.
4. Calculate quote.
5. Click Send Quote Email.
6. Confirm email arrives and status changes to Quoted.
